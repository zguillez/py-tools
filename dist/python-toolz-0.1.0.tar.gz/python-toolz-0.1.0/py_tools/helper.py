def log(txt):
    print(txt)
