from python_toolz import helper


log = helper.log
