# python-toolz v0.1.4

```pip install --upgrade python-toolz```

```
import python_toolz

python_toolz.log("test1")
```

```
from python_toolz import helper

helper.log("test2")
```
